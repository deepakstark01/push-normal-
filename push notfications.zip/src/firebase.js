

// import { initializeApp } from "firebase/app";

// const firebaseConfig = {
//   apiKey: "AIzaSyBa8d6KUQ1ZOf7fuSDa4yNVKKTUWLVWDhE",
//   authDomain: "push-notfication-f37bf.firebaseapp.com",
//   projectId: "push-notfication-f37bf",
//   storageBucket: "push-notfication-f37bf.appspot.com",
//   messagingSenderId: "647223993594",
//   appId: "1:647223993594:web:41767eb36802ab76df1543"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);

// export default firebase 


import firebase from "firebase/app";
const firebaseConfig = {
  // Your Firebase config here
  apiKey: "AIzaSyBa8d6KUQ1ZOf7fuSDa4yNVKKTUWLVWDhE",
  authDomain: "push-notfication-f37bf.firebaseapp.com",
  projectId: "push-notfication-f37bf",
  storageBucket: "push-notfication-f37bf.appspot.com",
  messagingSenderId: "647223993594",
  appId: "1:647223993594:web:41767eb36802ab76df1543"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);

export default firebase;
