import React, { useEffect } from "react";
import logo from './images/logo.jpg'
import addNotification from "react-push-notification";
function App() {
 
  const clickTonotify =()=>
  {
    addNotification(
      {
        title : 'Automartz',
        message: 'See new car deals',
        duration: 4000,
        icon:logo,
        native: true,
        onClick: ()=> console.log("Pushed notification")
      }
    )

  }
  useEffect(()=>{
    clickTonotify()
  },[])
  return (
    <div>
      <button onClick={clickTonotify}  >
        click to push notification
      </button>
    </div>
  );
}

export default App;
