import React from 'react'
export default function About()
{
    return(
        <div>
            <h1>Automartz</h1>
        </div>
    )
}