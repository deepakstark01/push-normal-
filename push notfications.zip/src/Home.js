import React from 'react'
export default function Home()
{
    return(
        <div style={{ backgroundColor: '#f2f2f2' }}>
        <h1>Welcome to automartz</h1>
      </div>
    )
}